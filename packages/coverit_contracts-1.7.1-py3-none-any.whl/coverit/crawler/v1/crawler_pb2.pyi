from validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CrawlStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CRAWL_STATUS_UNSPECIFIED: _ClassVar[CrawlStatus]
    CRAWL_STATUS_QUEUED: _ClassVar[CrawlStatus]
    CRAWL_STATUS_RUNNING: _ClassVar[CrawlStatus]
    CRAWL_STATUS_COMPLETED: _ClassVar[CrawlStatus]
    CRAWL_STATUS_FAILED: _ClassVar[CrawlStatus]
    CRAWL_STATUS_ABORTED: _ClassVar[CrawlStatus]
    CRAWL_STATUS_PAUSED: _ClassVar[CrawlStatus]
    CRAWL_STATUS_NEW: _ClassVar[CrawlStatus]

class CrawlTriggerType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CRAWL_TRIGGER_TYPE_UNSPECIFIED: _ClassVar[CrawlTriggerType]
    CRAWL_TRIGGER_TYPE_MANUAL: _ClassVar[CrawlTriggerType]
    CRAWL_TRIGGER_TYPE_SCHEDULED: _ClassVar[CrawlTriggerType]
    CRAWL_TRIGGER_TYPE_CI_TRIGGER: _ClassVar[CrawlTriggerType]
    CRAWL_TRIGGER_TYPE_WEBHOOK: _ClassVar[CrawlTriggerType]
CRAWL_STATUS_UNSPECIFIED: CrawlStatus
CRAWL_STATUS_QUEUED: CrawlStatus
CRAWL_STATUS_RUNNING: CrawlStatus
CRAWL_STATUS_COMPLETED: CrawlStatus
CRAWL_STATUS_FAILED: CrawlStatus
CRAWL_STATUS_ABORTED: CrawlStatus
CRAWL_STATUS_PAUSED: CrawlStatus
CRAWL_STATUS_NEW: CrawlStatus
CRAWL_TRIGGER_TYPE_UNSPECIFIED: CrawlTriggerType
CRAWL_TRIGGER_TYPE_MANUAL: CrawlTriggerType
CRAWL_TRIGGER_TYPE_SCHEDULED: CrawlTriggerType
CRAWL_TRIGGER_TYPE_CI_TRIGGER: CrawlTriggerType
CRAWL_TRIGGER_TYPE_WEBHOOK: CrawlTriggerType

class CrawlConfig(_message.Message):
    __slots__ = ("max_states", "max_depth", "include_url_patterns", "exclude_url_patterns", "enable_semantic_decisions", "headless", "timeout_seconds")
    MAX_STATES_FIELD_NUMBER: _ClassVar[int]
    MAX_DEPTH_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_URL_PATTERNS_FIELD_NUMBER: _ClassVar[int]
    EXCLUDE_URL_PATTERNS_FIELD_NUMBER: _ClassVar[int]
    ENABLE_SEMANTIC_DECISIONS_FIELD_NUMBER: _ClassVar[int]
    HEADLESS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_SECONDS_FIELD_NUMBER: _ClassVar[int]
    max_states: int
    max_depth: int
    include_url_patterns: _containers.RepeatedScalarFieldContainer[str]
    exclude_url_patterns: _containers.RepeatedScalarFieldContainer[str]
    enable_semantic_decisions: bool
    headless: bool
    timeout_seconds: int
    def __init__(self, max_states: _Optional[int] = ..., max_depth: _Optional[int] = ..., include_url_patterns: _Optional[_Iterable[str]] = ..., exclude_url_patterns: _Optional[_Iterable[str]] = ..., enable_semantic_decisions: _Optional[bool] = ..., headless: _Optional[bool] = ..., timeout_seconds: _Optional[int] = ...) -> None: ...

class CrawlSessionData(_message.Message):
    __slots__ = ("id", "app_version_id", "status", "trigger_type", "crawl_config", "state_count", "transition_count", "created_at", "started_at", "finished_at", "error_message")
    ID_FIELD_NUMBER: _ClassVar[int]
    APP_VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_TYPE_FIELD_NUMBER: _ClassVar[int]
    CRAWL_CONFIG_FIELD_NUMBER: _ClassVar[int]
    STATE_COUNT_FIELD_NUMBER: _ClassVar[int]
    TRANSITION_COUNT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    FINISHED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    id: str
    app_version_id: str
    status: CrawlStatus
    trigger_type: CrawlTriggerType
    crawl_config: CrawlConfig
    state_count: int
    transition_count: int
    created_at: str
    started_at: str
    finished_at: str
    error_message: str
    def __init__(self, id: _Optional[str] = ..., app_version_id: _Optional[str] = ..., status: _Optional[_Union[CrawlStatus, str]] = ..., trigger_type: _Optional[_Union[CrawlTriggerType, str]] = ..., crawl_config: _Optional[_Union[CrawlConfig, _Mapping]] = ..., state_count: _Optional[int] = ..., transition_count: _Optional[int] = ..., created_at: _Optional[str] = ..., started_at: _Optional[str] = ..., finished_at: _Optional[str] = ..., error_message: _Optional[str] = ...) -> None: ...

class CreateCrawlSessionRequest(_message.Message):
    __slots__ = ("trigger_type", "crawl_config")
    TRIGGER_TYPE_FIELD_NUMBER: _ClassVar[int]
    CRAWL_CONFIG_FIELD_NUMBER: _ClassVar[int]
    trigger_type: CrawlTriggerType
    crawl_config: CrawlConfig
    def __init__(self, trigger_type: _Optional[_Union[CrawlTriggerType, str]] = ..., crawl_config: _Optional[_Union[CrawlConfig, _Mapping]] = ...) -> None: ...

class ApplicationVersionCrawlSessionsResponse(_message.Message):
    __slots__ = ("sessions", "total_count", "current_page", "page_size")
    SESSIONS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    CURRENT_PAGE_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    sessions: _containers.RepeatedCompositeFieldContainer[CrawlSessionData]
    total_count: int
    current_page: int
    page_size: int
    def __init__(self, sessions: _Optional[_Iterable[_Union[CrawlSessionData, _Mapping]]] = ..., total_count: _Optional[int] = ..., current_page: _Optional[int] = ..., page_size: _Optional[int] = ...) -> None: ...

class CrawlSessionByIDResponse(_message.Message):
    __slots__ = ("session",)
    SESSION_FIELD_NUMBER: _ClassVar[int]
    session: CrawlSessionData
    def __init__(self, session: _Optional[_Union[CrawlSessionData, _Mapping]] = ...) -> None: ...

class StopCrawlSessionResponse(_message.Message):
    __slots__ = ("session",)
    SESSION_FIELD_NUMBER: _ClassVar[int]
    session: CrawlSessionData
    def __init__(self, session: _Optional[_Union[CrawlSessionData, _Mapping]] = ...) -> None: ...
