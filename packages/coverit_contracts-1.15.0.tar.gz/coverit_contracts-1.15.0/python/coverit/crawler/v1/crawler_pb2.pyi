from google.protobuf import struct_pb2 as _struct_pb2
from validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CrawlStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CRAWL_STATUS_UNSPECIFIED: _ClassVar[CrawlStatus]
    CRAWL_STATUS_QUEUED: _ClassVar[CrawlStatus]
    CRAWL_STATUS_RUNNING: _ClassVar[CrawlStatus]
    CRAWL_STATUS_COMPLETED: _ClassVar[CrawlStatus]
    CRAWL_STATUS_FAILED: _ClassVar[CrawlStatus]
    CRAWL_STATUS_ABORTED: _ClassVar[CrawlStatus]
    CRAWL_STATUS_PAUSED: _ClassVar[CrawlStatus]
    CRAWL_STATUS_NEW: _ClassVar[CrawlStatus]

class CrawlTriggerType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CRAWL_TRIGGER_TYPE_UNSPECIFIED: _ClassVar[CrawlTriggerType]
    CRAWL_TRIGGER_TYPE_MANUAL: _ClassVar[CrawlTriggerType]
    CRAWL_TRIGGER_TYPE_SCHEDULED: _ClassVar[CrawlTriggerType]
    CRAWL_TRIGGER_TYPE_CI_TRIGGER: _ClassVar[CrawlTriggerType]
    CRAWL_TRIGGER_TYPE_WEBHOOK: _ClassVar[CrawlTriggerType]

class CrawlScheduleType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CRAWL_SCHEDULE_TYPE_UNSPECIFIED: _ClassVar[CrawlScheduleType]
    CRAWL_SCHEDULE_TYPE_ONCE: _ClassVar[CrawlScheduleType]
    CRAWL_SCHEDULE_TYPE_CRON: _ClassVar[CrawlScheduleType]

class CrawlScheduleMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CRAWL_SCHEDULE_MODE_UNSPECIFIED: _ClassVar[CrawlScheduleMode]
    CRAWL_SCHEDULE_MODE_LATEST_VERSION: _ClassVar[CrawlScheduleMode]
    CRAWL_SCHEDULE_MODE_FIXED_VERSION: _ClassVar[CrawlScheduleMode]
CRAWL_STATUS_UNSPECIFIED: CrawlStatus
CRAWL_STATUS_QUEUED: CrawlStatus
CRAWL_STATUS_RUNNING: CrawlStatus
CRAWL_STATUS_COMPLETED: CrawlStatus
CRAWL_STATUS_FAILED: CrawlStatus
CRAWL_STATUS_ABORTED: CrawlStatus
CRAWL_STATUS_PAUSED: CrawlStatus
CRAWL_STATUS_NEW: CrawlStatus
CRAWL_TRIGGER_TYPE_UNSPECIFIED: CrawlTriggerType
CRAWL_TRIGGER_TYPE_MANUAL: CrawlTriggerType
CRAWL_TRIGGER_TYPE_SCHEDULED: CrawlTriggerType
CRAWL_TRIGGER_TYPE_CI_TRIGGER: CrawlTriggerType
CRAWL_TRIGGER_TYPE_WEBHOOK: CrawlTriggerType
CRAWL_SCHEDULE_TYPE_UNSPECIFIED: CrawlScheduleType
CRAWL_SCHEDULE_TYPE_ONCE: CrawlScheduleType
CRAWL_SCHEDULE_TYPE_CRON: CrawlScheduleType
CRAWL_SCHEDULE_MODE_UNSPECIFIED: CrawlScheduleMode
CRAWL_SCHEDULE_MODE_LATEST_VERSION: CrawlScheduleMode
CRAWL_SCHEDULE_MODE_FIXED_VERSION: CrawlScheduleMode

class CrawlerRunSettings(_message.Message):
    __slots__ = ("headless", "timeout_ms", "max_states", "max_transitions", "max_elements_per_state", "max_select_options_per_element", "max_action_repeats_per_url", "action_retry_count", "replay_retry_count", "popup_timeout_ms", "dom_quiet_ms", "dom_settle_timeout_ms", "use_dom_quiescence", "page_load_state", "click_non_http_links", "defer_destructive_actions", "destructive_keywords", "use_semantic_diversity", "semantic_diversity_threshold", "semantic_uncertainty_margin", "semantic_max_bank_size", "semantic_artifact_dir")
    HEADLESS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    MAX_STATES_FIELD_NUMBER: _ClassVar[int]
    MAX_TRANSITIONS_FIELD_NUMBER: _ClassVar[int]
    MAX_ELEMENTS_PER_STATE_FIELD_NUMBER: _ClassVar[int]
    MAX_SELECT_OPTIONS_PER_ELEMENT_FIELD_NUMBER: _ClassVar[int]
    MAX_ACTION_REPEATS_PER_URL_FIELD_NUMBER: _ClassVar[int]
    ACTION_RETRY_COUNT_FIELD_NUMBER: _ClassVar[int]
    REPLAY_RETRY_COUNT_FIELD_NUMBER: _ClassVar[int]
    POPUP_TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    DOM_QUIET_MS_FIELD_NUMBER: _ClassVar[int]
    DOM_SETTLE_TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    USE_DOM_QUIESCENCE_FIELD_NUMBER: _ClassVar[int]
    PAGE_LOAD_STATE_FIELD_NUMBER: _ClassVar[int]
    CLICK_NON_HTTP_LINKS_FIELD_NUMBER: _ClassVar[int]
    DEFER_DESTRUCTIVE_ACTIONS_FIELD_NUMBER: _ClassVar[int]
    DESTRUCTIVE_KEYWORDS_FIELD_NUMBER: _ClassVar[int]
    USE_SEMANTIC_DIVERSITY_FIELD_NUMBER: _ClassVar[int]
    SEMANTIC_DIVERSITY_THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    SEMANTIC_UNCERTAINTY_MARGIN_FIELD_NUMBER: _ClassVar[int]
    SEMANTIC_MAX_BANK_SIZE_FIELD_NUMBER: _ClassVar[int]
    SEMANTIC_ARTIFACT_DIR_FIELD_NUMBER: _ClassVar[int]
    headless: bool
    timeout_ms: int
    max_states: int
    max_transitions: int
    max_elements_per_state: int
    max_select_options_per_element: int
    max_action_repeats_per_url: int
    action_retry_count: int
    replay_retry_count: int
    popup_timeout_ms: int
    dom_quiet_ms: int
    dom_settle_timeout_ms: int
    use_dom_quiescence: bool
    page_load_state: str
    click_non_http_links: bool
    defer_destructive_actions: bool
    destructive_keywords: str
    use_semantic_diversity: bool
    semantic_diversity_threshold: float
    semantic_uncertainty_margin: float
    semantic_max_bank_size: int
    semantic_artifact_dir: str
    def __init__(self, headless: _Optional[bool] = ..., timeout_ms: _Optional[int] = ..., max_states: _Optional[int] = ..., max_transitions: _Optional[int] = ..., max_elements_per_state: _Optional[int] = ..., max_select_options_per_element: _Optional[int] = ..., max_action_repeats_per_url: _Optional[int] = ..., action_retry_count: _Optional[int] = ..., replay_retry_count: _Optional[int] = ..., popup_timeout_ms: _Optional[int] = ..., dom_quiet_ms: _Optional[int] = ..., dom_settle_timeout_ms: _Optional[int] = ..., use_dom_quiescence: _Optional[bool] = ..., page_load_state: _Optional[str] = ..., click_non_http_links: _Optional[bool] = ..., defer_destructive_actions: _Optional[bool] = ..., destructive_keywords: _Optional[str] = ..., use_semantic_diversity: _Optional[bool] = ..., semantic_diversity_threshold: _Optional[float] = ..., semantic_uncertainty_margin: _Optional[float] = ..., semantic_max_bank_size: _Optional[int] = ..., semantic_artifact_dir: _Optional[str] = ...) -> None: ...

class InputDefaultsConfig(_message.Message):
    __slots__ = ("field_patterns", "type_fallbacks")
    class FieldPatternsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    class TypeFallbacksEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    FIELD_PATTERNS_FIELD_NUMBER: _ClassVar[int]
    TYPE_FALLBACKS_FIELD_NUMBER: _ClassVar[int]
    field_patterns: _containers.ScalarMap[str, str]
    type_fallbacks: _containers.ScalarMap[str, str]
    def __init__(self, field_patterns: _Optional[_Mapping[str, str]] = ..., type_fallbacks: _Optional[_Mapping[str, str]] = ...) -> None: ...

class CrawlConfig(_message.Message):
    __slots__ = ("max_states", "max_depth", "include_url_patterns", "exclude_url_patterns", "enable_semantic_decisions", "timeout_seconds", "crawler_settings", "input_defaults")
    MAX_STATES_FIELD_NUMBER: _ClassVar[int]
    MAX_DEPTH_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_URL_PATTERNS_FIELD_NUMBER: _ClassVar[int]
    EXCLUDE_URL_PATTERNS_FIELD_NUMBER: _ClassVar[int]
    ENABLE_SEMANTIC_DECISIONS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_SECONDS_FIELD_NUMBER: _ClassVar[int]
    CRAWLER_SETTINGS_FIELD_NUMBER: _ClassVar[int]
    INPUT_DEFAULTS_FIELD_NUMBER: _ClassVar[int]
    max_states: int
    max_depth: int
    include_url_patterns: _containers.RepeatedScalarFieldContainer[str]
    exclude_url_patterns: _containers.RepeatedScalarFieldContainer[str]
    enable_semantic_decisions: bool
    timeout_seconds: int
    crawler_settings: CrawlerRunSettings
    input_defaults: InputDefaultsConfig
    def __init__(self, max_states: _Optional[int] = ..., max_depth: _Optional[int] = ..., include_url_patterns: _Optional[_Iterable[str]] = ..., exclude_url_patterns: _Optional[_Iterable[str]] = ..., enable_semantic_decisions: _Optional[bool] = ..., timeout_seconds: _Optional[int] = ..., crawler_settings: _Optional[_Union[CrawlerRunSettings, _Mapping]] = ..., input_defaults: _Optional[_Union[InputDefaultsConfig, _Mapping]] = ...) -> None: ...

class CodegenConfig(_message.Message):
    __slots__ = ("codegen_branch", "pr_target_branch", "pr_title", "pr_body", "pr_draft")
    CODEGEN_BRANCH_FIELD_NUMBER: _ClassVar[int]
    PR_TARGET_BRANCH_FIELD_NUMBER: _ClassVar[int]
    PR_TITLE_FIELD_NUMBER: _ClassVar[int]
    PR_BODY_FIELD_NUMBER: _ClassVar[int]
    PR_DRAFT_FIELD_NUMBER: _ClassVar[int]
    codegen_branch: str
    pr_target_branch: str
    pr_title: str
    pr_body: str
    pr_draft: bool
    def __init__(self, codegen_branch: _Optional[str] = ..., pr_target_branch: _Optional[str] = ..., pr_title: _Optional[str] = ..., pr_body: _Optional[str] = ..., pr_draft: _Optional[bool] = ...) -> None: ...

class CrawlSessionData(_message.Message):
    __slots__ = ("id", "app_version_id", "status", "trigger_type", "crawl_config", "regression_codebase_id", "codegen_config", "base_url_snapshot", "schedule_id", "state_count", "transition_count", "created_at", "started_at", "finished_at", "error_message")
    ID_FIELD_NUMBER: _ClassVar[int]
    APP_VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_TYPE_FIELD_NUMBER: _ClassVar[int]
    CRAWL_CONFIG_FIELD_NUMBER: _ClassVar[int]
    REGRESSION_CODEBASE_ID_FIELD_NUMBER: _ClassVar[int]
    CODEGEN_CONFIG_FIELD_NUMBER: _ClassVar[int]
    BASE_URL_SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_ID_FIELD_NUMBER: _ClassVar[int]
    STATE_COUNT_FIELD_NUMBER: _ClassVar[int]
    TRANSITION_COUNT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    FINISHED_AT_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    id: str
    app_version_id: str
    status: CrawlStatus
    trigger_type: CrawlTriggerType
    crawl_config: CrawlConfig
    regression_codebase_id: str
    codegen_config: CodegenConfig
    base_url_snapshot: str
    schedule_id: str
    state_count: int
    transition_count: int
    created_at: str
    started_at: str
    finished_at: str
    error_message: str
    def __init__(self, id: _Optional[str] = ..., app_version_id: _Optional[str] = ..., status: _Optional[_Union[CrawlStatus, str]] = ..., trigger_type: _Optional[_Union[CrawlTriggerType, str]] = ..., crawl_config: _Optional[_Union[CrawlConfig, _Mapping]] = ..., regression_codebase_id: _Optional[str] = ..., codegen_config: _Optional[_Union[CodegenConfig, _Mapping]] = ..., base_url_snapshot: _Optional[str] = ..., schedule_id: _Optional[str] = ..., state_count: _Optional[int] = ..., transition_count: _Optional[int] = ..., created_at: _Optional[str] = ..., started_at: _Optional[str] = ..., finished_at: _Optional[str] = ..., error_message: _Optional[str] = ...) -> None: ...

class FlowStep(_message.Message):
    __slots__ = ("state_hash", "transition")
    STATE_HASH_FIELD_NUMBER: _ClassVar[int]
    TRANSITION_FIELD_NUMBER: _ClassVar[int]
    state_hash: str
    transition: _struct_pb2.Struct
    def __init__(self, state_hash: _Optional[str] = ..., transition: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class SerializedFlow(_message.Message):
    __slots__ = ("checkpoint", "checkpoint_url", "is_clipped", "path")
    CHECKPOINT_FIELD_NUMBER: _ClassVar[int]
    CHECKPOINT_URL_FIELD_NUMBER: _ClassVar[int]
    IS_CLIPPED_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    checkpoint: str
    checkpoint_url: str
    is_clipped: bool
    path: _containers.RepeatedCompositeFieldContainer[FlowStep]
    def __init__(self, checkpoint: _Optional[str] = ..., checkpoint_url: _Optional[str] = ..., is_clipped: _Optional[bool] = ..., path: _Optional[_Iterable[_Union[FlowStep, _Mapping]]] = ...) -> None: ...

class CreateCrawlSessionRequest(_message.Message):
    __slots__ = ("trigger_type", "crawl_config", "regression_codebase_id", "codegen_config")
    TRIGGER_TYPE_FIELD_NUMBER: _ClassVar[int]
    CRAWL_CONFIG_FIELD_NUMBER: _ClassVar[int]
    REGRESSION_CODEBASE_ID_FIELD_NUMBER: _ClassVar[int]
    CODEGEN_CONFIG_FIELD_NUMBER: _ClassVar[int]
    trigger_type: CrawlTriggerType
    crawl_config: CrawlConfig
    regression_codebase_id: str
    codegen_config: CodegenConfig
    def __init__(self, trigger_type: _Optional[_Union[CrawlTriggerType, str]] = ..., crawl_config: _Optional[_Union[CrawlConfig, _Mapping]] = ..., regression_codebase_id: _Optional[str] = ..., codegen_config: _Optional[_Union[CodegenConfig, _Mapping]] = ...) -> None: ...

class CreateCrawlScheduleRequest(_message.Message):
    __slots__ = ("schedule_type", "mode", "version_id", "cron", "timezone", "run_at", "is_active", "catch_up", "crawl_config", "codegen_config", "regression_codebase_id")
    SCHEDULE_TYPE_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    CRON_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    RUN_AT_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    CATCH_UP_FIELD_NUMBER: _ClassVar[int]
    CRAWL_CONFIG_FIELD_NUMBER: _ClassVar[int]
    CODEGEN_CONFIG_FIELD_NUMBER: _ClassVar[int]
    REGRESSION_CODEBASE_ID_FIELD_NUMBER: _ClassVar[int]
    schedule_type: CrawlScheduleType
    mode: CrawlScheduleMode
    version_id: str
    cron: str
    timezone: str
    run_at: str
    is_active: bool
    catch_up: bool
    crawl_config: CrawlConfig
    codegen_config: CodegenConfig
    regression_codebase_id: str
    def __init__(self, schedule_type: _Optional[_Union[CrawlScheduleType, str]] = ..., mode: _Optional[_Union[CrawlScheduleMode, str]] = ..., version_id: _Optional[str] = ..., cron: _Optional[str] = ..., timezone: _Optional[str] = ..., run_at: _Optional[str] = ..., is_active: _Optional[bool] = ..., catch_up: _Optional[bool] = ..., crawl_config: _Optional[_Union[CrawlConfig, _Mapping]] = ..., codegen_config: _Optional[_Union[CodegenConfig, _Mapping]] = ..., regression_codebase_id: _Optional[str] = ...) -> None: ...

class UpdateCrawlScheduleRequest(_message.Message):
    __slots__ = ("schedule_type", "mode", "version_id", "cron", "timezone", "run_at", "is_active", "catch_up", "crawl_config", "codegen_config", "regression_codebase_id")
    SCHEDULE_TYPE_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    CRON_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    RUN_AT_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    CATCH_UP_FIELD_NUMBER: _ClassVar[int]
    CRAWL_CONFIG_FIELD_NUMBER: _ClassVar[int]
    CODEGEN_CONFIG_FIELD_NUMBER: _ClassVar[int]
    REGRESSION_CODEBASE_ID_FIELD_NUMBER: _ClassVar[int]
    schedule_type: CrawlScheduleType
    mode: CrawlScheduleMode
    version_id: str
    cron: str
    timezone: str
    run_at: str
    is_active: bool
    catch_up: bool
    crawl_config: CrawlConfig
    codegen_config: CodegenConfig
    regression_codebase_id: str
    def __init__(self, schedule_type: _Optional[_Union[CrawlScheduleType, str]] = ..., mode: _Optional[_Union[CrawlScheduleMode, str]] = ..., version_id: _Optional[str] = ..., cron: _Optional[str] = ..., timezone: _Optional[str] = ..., run_at: _Optional[str] = ..., is_active: _Optional[bool] = ..., catch_up: _Optional[bool] = ..., crawl_config: _Optional[_Union[CrawlConfig, _Mapping]] = ..., codegen_config: _Optional[_Union[CodegenConfig, _Mapping]] = ..., regression_codebase_id: _Optional[str] = ...) -> None: ...

class SaveAllFlowsRequest(_message.Message):
    __slots__ = ("flows",)
    class FlowsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: SerializedFlowList
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[SerializedFlowList, _Mapping]] = ...) -> None: ...
    FLOWS_FIELD_NUMBER: _ClassVar[int]
    flows: _containers.MessageMap[str, SerializedFlowList]
    def __init__(self, flows: _Optional[_Mapping[str, SerializedFlowList]] = ...) -> None: ...

class SerializedFlowList(_message.Message):
    __slots__ = ("flows",)
    FLOWS_FIELD_NUMBER: _ClassVar[int]
    flows: _containers.RepeatedCompositeFieldContainer[SerializedFlow]
    def __init__(self, flows: _Optional[_Iterable[_Union[SerializedFlow, _Mapping]]] = ...) -> None: ...

class ApplicationVersionCrawlSessionsResponse(_message.Message):
    __slots__ = ("sessions", "total_count", "current_page", "page_size")
    SESSIONS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    CURRENT_PAGE_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    sessions: _containers.RepeatedCompositeFieldContainer[CrawlSessionData]
    total_count: int
    current_page: int
    page_size: int
    def __init__(self, sessions: _Optional[_Iterable[_Union[CrawlSessionData, _Mapping]]] = ..., total_count: _Optional[int] = ..., current_page: _Optional[int] = ..., page_size: _Optional[int] = ...) -> None: ...

class CrawlSessionByIDResponse(_message.Message):
    __slots__ = ("session",)
    SESSION_FIELD_NUMBER: _ClassVar[int]
    session: CrawlSessionData
    def __init__(self, session: _Optional[_Union[CrawlSessionData, _Mapping]] = ...) -> None: ...

class StopCrawlSessionResponse(_message.Message):
    __slots__ = ("session",)
    SESSION_FIELD_NUMBER: _ClassVar[int]
    session: CrawlSessionData
    def __init__(self, session: _Optional[_Union[CrawlSessionData, _Mapping]] = ...) -> None: ...

class CrawlScheduleData(_message.Message):
    __slots__ = ("id", "target_application_id", "schedule_type", "mode", "version_id", "cron", "timezone", "run_at", "is_active", "catch_up", "crawl_config", "codegen_config", "regression_codebase_id", "next_run_at", "last_run_at", "created_at", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_APPLICATION_ID_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_TYPE_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    CRON_FIELD_NUMBER: _ClassVar[int]
    TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    RUN_AT_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    CATCH_UP_FIELD_NUMBER: _ClassVar[int]
    CRAWL_CONFIG_FIELD_NUMBER: _ClassVar[int]
    CODEGEN_CONFIG_FIELD_NUMBER: _ClassVar[int]
    REGRESSION_CODEBASE_ID_FIELD_NUMBER: _ClassVar[int]
    NEXT_RUN_AT_FIELD_NUMBER: _ClassVar[int]
    LAST_RUN_AT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    target_application_id: str
    schedule_type: CrawlScheduleType
    mode: CrawlScheduleMode
    version_id: str
    cron: str
    timezone: str
    run_at: str
    is_active: bool
    catch_up: bool
    crawl_config: CrawlConfig
    codegen_config: CodegenConfig
    regression_codebase_id: str
    next_run_at: str
    last_run_at: str
    created_at: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., target_application_id: _Optional[str] = ..., schedule_type: _Optional[_Union[CrawlScheduleType, str]] = ..., mode: _Optional[_Union[CrawlScheduleMode, str]] = ..., version_id: _Optional[str] = ..., cron: _Optional[str] = ..., timezone: _Optional[str] = ..., run_at: _Optional[str] = ..., is_active: _Optional[bool] = ..., catch_up: _Optional[bool] = ..., crawl_config: _Optional[_Union[CrawlConfig, _Mapping]] = ..., codegen_config: _Optional[_Union[CodegenConfig, _Mapping]] = ..., regression_codebase_id: _Optional[str] = ..., next_run_at: _Optional[str] = ..., last_run_at: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class CrawlScheduleListResponse(_message.Message):
    __slots__ = ("schedules",)
    SCHEDULES_FIELD_NUMBER: _ClassVar[int]
    schedules: _containers.RepeatedCompositeFieldContainer[CrawlScheduleData]
    def __init__(self, schedules: _Optional[_Iterable[_Union[CrawlScheduleData, _Mapping]]] = ...) -> None: ...
