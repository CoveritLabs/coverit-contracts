from validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class StartIntegrationOAuthRequest(_message.Message):
    __slots__ = ("site_url",)
    SITE_URL_FIELD_NUMBER: _ClassVar[int]
    site_url: str
    def __init__(self, site_url: _Optional[str] = ...) -> None: ...

class StartIntegrationOAuthResponse(_message.Message):
    __slots__ = ("authorization_url",)
    AUTHORIZATION_URL_FIELD_NUMBER: _ClassVar[int]
    authorization_url: str
    def __init__(self, authorization_url: _Optional[str] = ...) -> None: ...

class IntegrationStatusResponse(_message.Message):
    __slots__ = ("connected", "provider", "scopes", "authorized_by_user_id", "access_token_expires_at", "refreshed_at", "created_at", "updated_at", "jira")
    CONNECTED_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    SCOPES_FIELD_NUMBER: _ClassVar[int]
    AUTHORIZED_BY_USER_ID_FIELD_NUMBER: _ClassVar[int]
    ACCESS_TOKEN_EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    REFRESHED_AT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    JIRA_FIELD_NUMBER: _ClassVar[int]
    connected: bool
    provider: str
    scopes: _containers.RepeatedScalarFieldContainer[str]
    authorized_by_user_id: str
    access_token_expires_at: str
    refreshed_at: str
    created_at: str
    updated_at: str
    jira: JiraIntegrationDetails
    def __init__(self, connected: _Optional[bool] = ..., provider: _Optional[str] = ..., scopes: _Optional[_Iterable[str]] = ..., authorized_by_user_id: _Optional[str] = ..., access_token_expires_at: _Optional[str] = ..., refreshed_at: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., jira: _Optional[_Union[JiraIntegrationDetails, _Mapping]] = ...) -> None: ...

class JiraIntegrationDetails(_message.Message):
    __slots__ = ("cloud_id", "site_name", "site_url")
    CLOUD_ID_FIELD_NUMBER: _ClassVar[int]
    SITE_NAME_FIELD_NUMBER: _ClassVar[int]
    SITE_URL_FIELD_NUMBER: _ClassVar[int]
    cloud_id: str
    site_name: str
    site_url: str
    def __init__(self, cloud_id: _Optional[str] = ..., site_name: _Optional[str] = ..., site_url: _Optional[str] = ...) -> None: ...
