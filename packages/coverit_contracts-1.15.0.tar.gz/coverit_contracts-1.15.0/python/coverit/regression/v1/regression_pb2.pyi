from google.protobuf import struct_pb2 as _struct_pb2
from validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RegressionRunStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    REGRESSION_RUN_STATUS_UNSPECIFIED: _ClassVar[RegressionRunStatus]
    REGRESSION_RUN_STATUS_RUNNING: _ClassVar[RegressionRunStatus]
    REGRESSION_RUN_STATUS_PASSED: _ClassVar[RegressionRunStatus]
    REGRESSION_RUN_STATUS_FAILED: _ClassVar[RegressionRunStatus]

class RegressionScenarioStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    REGRESSION_SCENARIO_STATUS_UNSPECIFIED: _ClassVar[RegressionScenarioStatus]
    REGRESSION_SCENARIO_STATUS_RUNNING: _ClassVar[RegressionScenarioStatus]
    REGRESSION_SCENARIO_STATUS_PASSED: _ClassVar[RegressionScenarioStatus]
    REGRESSION_SCENARIO_STATUS_FAILED: _ClassVar[RegressionScenarioStatus]

class RegressionArtifactKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    REGRESSION_ARTIFACT_KIND_UNSPECIFIED: _ClassVar[RegressionArtifactKind]
    REGRESSION_ARTIFACT_KIND_FAILURE: _ClassVar[RegressionArtifactKind]
    REGRESSION_ARTIFACT_KIND_LOG: _ClassVar[RegressionArtifactKind]
    REGRESSION_ARTIFACT_KIND_HEALING: _ClassVar[RegressionArtifactKind]
    REGRESSION_ARTIFACT_KIND_SUMMARY: _ClassVar[RegressionArtifactKind]
    REGRESSION_ARTIFACT_KIND_OTHER: _ClassVar[RegressionArtifactKind]
    REGRESSION_ARTIFACT_KIND_SCREENSHOT: _ClassVar[RegressionArtifactKind]
    REGRESSION_ARTIFACT_KIND_VIDEO: _ClassVar[RegressionArtifactKind]
    REGRESSION_ARTIFACT_KIND_TRACE: _ClassVar[RegressionArtifactKind]
    REGRESSION_ARTIFACT_KIND_EVENTS: _ClassVar[RegressionArtifactKind]

class RegressionArtifactUploadStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    REGRESSION_ARTIFACT_UPLOAD_STATUS_UNSPECIFIED: _ClassVar[RegressionArtifactUploadStatus]
    REGRESSION_ARTIFACT_UPLOAD_STATUS_UPLOADED: _ClassVar[RegressionArtifactUploadStatus]
    REGRESSION_ARTIFACT_UPLOAD_STATUS_FAILED: _ClassVar[RegressionArtifactUploadStatus]

class RegressionArtifactTreeNodeType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    REGRESSION_ARTIFACT_TREE_NODE_TYPE_UNSPECIFIED: _ClassVar[RegressionArtifactTreeNodeType]
    REGRESSION_ARTIFACT_TREE_NODE_TYPE_FOLDER: _ClassVar[RegressionArtifactTreeNodeType]
    REGRESSION_ARTIFACT_TREE_NODE_TYPE_FILE: _ClassVar[RegressionArtifactTreeNodeType]
REGRESSION_RUN_STATUS_UNSPECIFIED: RegressionRunStatus
REGRESSION_RUN_STATUS_RUNNING: RegressionRunStatus
REGRESSION_RUN_STATUS_PASSED: RegressionRunStatus
REGRESSION_RUN_STATUS_FAILED: RegressionRunStatus
REGRESSION_SCENARIO_STATUS_UNSPECIFIED: RegressionScenarioStatus
REGRESSION_SCENARIO_STATUS_RUNNING: RegressionScenarioStatus
REGRESSION_SCENARIO_STATUS_PASSED: RegressionScenarioStatus
REGRESSION_SCENARIO_STATUS_FAILED: RegressionScenarioStatus
REGRESSION_ARTIFACT_KIND_UNSPECIFIED: RegressionArtifactKind
REGRESSION_ARTIFACT_KIND_FAILURE: RegressionArtifactKind
REGRESSION_ARTIFACT_KIND_LOG: RegressionArtifactKind
REGRESSION_ARTIFACT_KIND_HEALING: RegressionArtifactKind
REGRESSION_ARTIFACT_KIND_SUMMARY: RegressionArtifactKind
REGRESSION_ARTIFACT_KIND_OTHER: RegressionArtifactKind
REGRESSION_ARTIFACT_KIND_SCREENSHOT: RegressionArtifactKind
REGRESSION_ARTIFACT_KIND_VIDEO: RegressionArtifactKind
REGRESSION_ARTIFACT_KIND_TRACE: RegressionArtifactKind
REGRESSION_ARTIFACT_KIND_EVENTS: RegressionArtifactKind
REGRESSION_ARTIFACT_UPLOAD_STATUS_UNSPECIFIED: RegressionArtifactUploadStatus
REGRESSION_ARTIFACT_UPLOAD_STATUS_UPLOADED: RegressionArtifactUploadStatus
REGRESSION_ARTIFACT_UPLOAD_STATUS_FAILED: RegressionArtifactUploadStatus
REGRESSION_ARTIFACT_TREE_NODE_TYPE_UNSPECIFIED: RegressionArtifactTreeNodeType
REGRESSION_ARTIFACT_TREE_NODE_TYPE_FOLDER: RegressionArtifactTreeNodeType
REGRESSION_ARTIFACT_TREE_NODE_TYPE_FILE: RegressionArtifactTreeNodeType

class RegressionHealingInfo(_message.Message):
    __slots__ = ("was_healed", "original_selector", "healed_selector", "score", "reason", "breakdown")
    class BreakdownEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: float
        def __init__(self, key: _Optional[str] = ..., value: _Optional[float] = ...) -> None: ...
    WAS_HEALED_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_SELECTOR_FIELD_NUMBER: _ClassVar[int]
    HEALED_SELECTOR_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    BREAKDOWN_FIELD_NUMBER: _ClassVar[int]
    was_healed: bool
    original_selector: str
    healed_selector: str
    score: float
    reason: str
    breakdown: _containers.ScalarMap[str, float]
    def __init__(self, was_healed: _Optional[bool] = ..., original_selector: _Optional[str] = ..., healed_selector: _Optional[str] = ..., score: _Optional[float] = ..., reason: _Optional[str] = ..., breakdown: _Optional[_Mapping[str, float]] = ...) -> None: ...

class RegressionAssertionResult(_message.Message):
    __slots__ = ("name", "passed", "severity", "message", "details", "healing_info")
    NAME_FIELD_NUMBER: _ClassVar[int]
    PASSED_FIELD_NUMBER: _ClassVar[int]
    SEVERITY_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    DETAILS_FIELD_NUMBER: _ClassVar[int]
    HEALING_INFO_FIELD_NUMBER: _ClassVar[int]
    name: str
    passed: bool
    severity: str
    message: str
    details: str
    healing_info: RegressionHealingInfo
    def __init__(self, name: _Optional[str] = ..., passed: _Optional[bool] = ..., severity: _Optional[str] = ..., message: _Optional[str] = ..., details: _Optional[str] = ..., healing_info: _Optional[_Union[RegressionHealingInfo, _Mapping]] = ...) -> None: ...

class RegressionStepReport(_message.Message):
    __slots__ = ("step_type", "id", "label", "results", "all_passed")
    STEP_TYPE_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    ALL_PASSED_FIELD_NUMBER: _ClassVar[int]
    step_type: str
    id: str
    label: str
    results: _containers.RepeatedCompositeFieldContainer[RegressionAssertionResult]
    all_passed: bool
    def __init__(self, step_type: _Optional[str] = ..., id: _Optional[str] = ..., label: _Optional[str] = ..., results: _Optional[_Iterable[_Union[RegressionAssertionResult, _Mapping]]] = ..., all_passed: _Optional[bool] = ...) -> None: ...

class RegressionRunSummary(_message.Message):
    __slots__ = ("status", "started_at", "finished_at", "duration_ms", "passed", "failed", "warnings", "reports")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    FINISHED_AT_FIELD_NUMBER: _ClassVar[int]
    DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    PASSED_FIELD_NUMBER: _ClassVar[int]
    FAILED_FIELD_NUMBER: _ClassVar[int]
    WARNINGS_FIELD_NUMBER: _ClassVar[int]
    REPORTS_FIELD_NUMBER: _ClassVar[int]
    status: str
    started_at: str
    finished_at: str
    duration_ms: int
    passed: int
    failed: int
    warnings: int
    reports: _containers.RepeatedCompositeFieldContainer[RegressionStepReport]
    def __init__(self, status: _Optional[str] = ..., started_at: _Optional[str] = ..., finished_at: _Optional[str] = ..., duration_ms: _Optional[int] = ..., passed: _Optional[int] = ..., failed: _Optional[int] = ..., warnings: _Optional[int] = ..., reports: _Optional[_Iterable[_Union[RegressionStepReport, _Mapping]]] = ...) -> None: ...

class RegressionRun(_message.Message):
    __slots__ = ("id", "run_id", "application_id", "version_id", "status", "started_at", "finished_at", "duration_ms", "passed_count", "failed_count", "warning_count", "created_at", "updated_at", "name", "name_number", "display_name")
    ID_FIELD_NUMBER: _ClassVar[int]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    FINISHED_AT_FIELD_NUMBER: _ClassVar[int]
    DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    PASSED_COUNT_FIELD_NUMBER: _ClassVar[int]
    FAILED_COUNT_FIELD_NUMBER: _ClassVar[int]
    WARNING_COUNT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_NUMBER_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    id: str
    run_id: str
    application_id: str
    version_id: str
    status: str
    started_at: str
    finished_at: str
    duration_ms: int
    passed_count: int
    failed_count: int
    warning_count: int
    created_at: str
    updated_at: str
    name: str
    name_number: int
    display_name: str
    def __init__(self, id: _Optional[str] = ..., run_id: _Optional[str] = ..., application_id: _Optional[str] = ..., version_id: _Optional[str] = ..., status: _Optional[str] = ..., started_at: _Optional[str] = ..., finished_at: _Optional[str] = ..., duration_ms: _Optional[int] = ..., passed_count: _Optional[int] = ..., failed_count: _Optional[int] = ..., warning_count: _Optional[int] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., name: _Optional[str] = ..., name_number: _Optional[int] = ..., display_name: _Optional[str] = ...) -> None: ...

class RegressionScenario(_message.Message):
    __slots__ = ("id", "run_id", "scenario_key", "feature_name", "scenario_name", "title", "file", "line", "status", "started_at", "finished_at", "duration_ms", "passed_count", "failed_count", "warning_count")
    ID_FIELD_NUMBER: _ClassVar[int]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    SCENARIO_KEY_FIELD_NUMBER: _ClassVar[int]
    FEATURE_NAME_FIELD_NUMBER: _ClassVar[int]
    SCENARIO_NAME_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    LINE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    FINISHED_AT_FIELD_NUMBER: _ClassVar[int]
    DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    PASSED_COUNT_FIELD_NUMBER: _ClassVar[int]
    FAILED_COUNT_FIELD_NUMBER: _ClassVar[int]
    WARNING_COUNT_FIELD_NUMBER: _ClassVar[int]
    id: str
    run_id: str
    scenario_key: str
    feature_name: str
    scenario_name: str
    title: str
    file: str
    line: int
    status: str
    started_at: str
    finished_at: str
    duration_ms: int
    passed_count: int
    failed_count: int
    warning_count: int
    def __init__(self, id: _Optional[str] = ..., run_id: _Optional[str] = ..., scenario_key: _Optional[str] = ..., feature_name: _Optional[str] = ..., scenario_name: _Optional[str] = ..., title: _Optional[str] = ..., file: _Optional[str] = ..., line: _Optional[int] = ..., status: _Optional[str] = ..., started_at: _Optional[str] = ..., finished_at: _Optional[str] = ..., duration_ms: _Optional[int] = ..., passed_count: _Optional[int] = ..., failed_count: _Optional[int] = ..., warning_count: _Optional[int] = ...) -> None: ...

class RegressionEvent(_message.Message):
    __slots__ = ("id", "run_id", "scenario_id", "type", "timestamp", "feature_name", "scenario_name", "step_id", "step_label", "step_type", "status", "log_level", "has_failure", "has_healing", "payload", "run_name")
    ID_FIELD_NUMBER: _ClassVar[int]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    SCENARIO_ID_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    FEATURE_NAME_FIELD_NUMBER: _ClassVar[int]
    SCENARIO_NAME_FIELD_NUMBER: _ClassVar[int]
    STEP_ID_FIELD_NUMBER: _ClassVar[int]
    STEP_LABEL_FIELD_NUMBER: _ClassVar[int]
    STEP_TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    LOG_LEVEL_FIELD_NUMBER: _ClassVar[int]
    HAS_FAILURE_FIELD_NUMBER: _ClassVar[int]
    HAS_HEALING_FIELD_NUMBER: _ClassVar[int]
    PAYLOAD_FIELD_NUMBER: _ClassVar[int]
    RUN_NAME_FIELD_NUMBER: _ClassVar[int]
    id: str
    run_id: str
    scenario_id: str
    type: str
    timestamp: str
    feature_name: str
    scenario_name: str
    step_id: str
    step_label: str
    step_type: str
    status: str
    log_level: str
    has_failure: bool
    has_healing: bool
    payload: _struct_pb2.Value
    run_name: str
    def __init__(self, id: _Optional[str] = ..., run_id: _Optional[str] = ..., scenario_id: _Optional[str] = ..., type: _Optional[str] = ..., timestamp: _Optional[str] = ..., feature_name: _Optional[str] = ..., scenario_name: _Optional[str] = ..., step_id: _Optional[str] = ..., step_label: _Optional[str] = ..., step_type: _Optional[str] = ..., status: _Optional[str] = ..., log_level: _Optional[str] = ..., has_failure: _Optional[bool] = ..., has_healing: _Optional[bool] = ..., payload: _Optional[_Union[_struct_pb2.Value, _Mapping]] = ..., run_name: _Optional[str] = ...) -> None: ...

class RegressionArtifact(_message.Message):
    __slots__ = ("id", "run_id", "scenario_id", "kind", "name", "data", "created_at", "content_type", "size_bytes", "storage_provider", "storage_uri", "storage_path", "checksum_sha256", "upload_status", "upload_error", "metadata", "download_url", "updated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    SCENARIO_ID_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    CONTENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    STORAGE_PROVIDER_FIELD_NUMBER: _ClassVar[int]
    STORAGE_URI_FIELD_NUMBER: _ClassVar[int]
    STORAGE_PATH_FIELD_NUMBER: _ClassVar[int]
    CHECKSUM_SHA256_FIELD_NUMBER: _ClassVar[int]
    UPLOAD_STATUS_FIELD_NUMBER: _ClassVar[int]
    UPLOAD_ERROR_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    DOWNLOAD_URL_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    run_id: str
    scenario_id: str
    kind: str
    name: str
    data: _struct_pb2.Value
    created_at: str
    content_type: str
    size_bytes: int
    storage_provider: str
    storage_uri: str
    storage_path: str
    checksum_sha256: str
    upload_status: str
    upload_error: str
    metadata: _struct_pb2.Value
    download_url: str
    updated_at: str
    def __init__(self, id: _Optional[str] = ..., run_id: _Optional[str] = ..., scenario_id: _Optional[str] = ..., kind: _Optional[str] = ..., name: _Optional[str] = ..., data: _Optional[_Union[_struct_pb2.Value, _Mapping]] = ..., created_at: _Optional[str] = ..., content_type: _Optional[str] = ..., size_bytes: _Optional[int] = ..., storage_provider: _Optional[str] = ..., storage_uri: _Optional[str] = ..., storage_path: _Optional[str] = ..., checksum_sha256: _Optional[str] = ..., upload_status: _Optional[str] = ..., upload_error: _Optional[str] = ..., metadata: _Optional[_Union[_struct_pb2.Value, _Mapping]] = ..., download_url: _Optional[str] = ..., updated_at: _Optional[str] = ...) -> None: ...

class RegressionArtifactTreeNode(_message.Message):
    __slots__ = ("id", "name", "path", "type", "artifact", "children", "artifact_count", "size_bytes")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_FIELD_NUMBER: _ClassVar[int]
    CHILDREN_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_COUNT_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    path: str
    type: str
    artifact: RegressionArtifact
    children: _containers.RepeatedCompositeFieldContainer[RegressionArtifactTreeNode]
    artifact_count: int
    size_bytes: int
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., path: _Optional[str] = ..., type: _Optional[str] = ..., artifact: _Optional[_Union[RegressionArtifact, _Mapping]] = ..., children: _Optional[_Iterable[_Union[RegressionArtifactTreeNode, _Mapping]]] = ..., artifact_count: _Optional[int] = ..., size_bytes: _Optional[int] = ...) -> None: ...

class RegressionArtifactUploadResponse(_message.Message):
    __slots__ = ("artifact", "message")
    ARTIFACT_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    artifact: RegressionArtifact
    message: str
    def __init__(self, artifact: _Optional[_Union[RegressionArtifact, _Mapping]] = ..., message: _Optional[str] = ...) -> None: ...

class RegressionArtifactResponse(_message.Message):
    __slots__ = ("artifact",)
    ARTIFACT_FIELD_NUMBER: _ClassVar[int]
    artifact: RegressionArtifact
    def __init__(self, artifact: _Optional[_Union[RegressionArtifact, _Mapping]] = ...) -> None: ...

class RegressionArtifactDownloadResponse(_message.Message):
    __slots__ = ("download_url", "expires_at")
    DOWNLOAD_URL_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    download_url: str
    expires_at: str
    def __init__(self, download_url: _Optional[str] = ..., expires_at: _Optional[str] = ...) -> None: ...

class ListRegressionRunsRequest(_message.Message):
    __slots__ = ("version_id", "status", "limit", "cursor")
    VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    CURSOR_FIELD_NUMBER: _ClassVar[int]
    version_id: str
    status: str
    limit: int
    cursor: str
    def __init__(self, version_id: _Optional[str] = ..., status: _Optional[str] = ..., limit: _Optional[int] = ..., cursor: _Optional[str] = ...) -> None: ...

class ListRegressionRunsResponse(_message.Message):
    __slots__ = ("runs", "next_cursor")
    RUNS_FIELD_NUMBER: _ClassVar[int]
    NEXT_CURSOR_FIELD_NUMBER: _ClassVar[int]
    runs: _containers.RepeatedCompositeFieldContainer[RegressionRun]
    next_cursor: str
    def __init__(self, runs: _Optional[_Iterable[_Union[RegressionRun, _Mapping]]] = ..., next_cursor: _Optional[str] = ...) -> None: ...

class RegressionRunResponse(_message.Message):
    __slots__ = ("run",)
    RUN_FIELD_NUMBER: _ClassVar[int]
    run: RegressionRun
    def __init__(self, run: _Optional[_Union[RegressionRun, _Mapping]] = ...) -> None: ...

class ListRegressionScenariosResponse(_message.Message):
    __slots__ = ("scenarios",)
    SCENARIOS_FIELD_NUMBER: _ClassVar[int]
    scenarios: _containers.RepeatedCompositeFieldContainer[RegressionScenario]
    def __init__(self, scenarios: _Optional[_Iterable[_Union[RegressionScenario, _Mapping]]] = ...) -> None: ...

class RegressionScenarioResponse(_message.Message):
    __slots__ = ("scenario",)
    SCENARIO_FIELD_NUMBER: _ClassVar[int]
    scenario: RegressionScenario
    def __init__(self, scenario: _Optional[_Union[RegressionScenario, _Mapping]] = ...) -> None: ...

class ListRegressionEventsRequest(_message.Message):
    __slots__ = ("type", "limit", "cursor")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    CURSOR_FIELD_NUMBER: _ClassVar[int]
    type: str
    limit: int
    cursor: str
    def __init__(self, type: _Optional[str] = ..., limit: _Optional[int] = ..., cursor: _Optional[str] = ...) -> None: ...

class ListRegressionEventsResponse(_message.Message):
    __slots__ = ("events", "next_cursor")
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    NEXT_CURSOR_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[RegressionEvent]
    next_cursor: str
    def __init__(self, events: _Optional[_Iterable[_Union[RegressionEvent, _Mapping]]] = ..., next_cursor: _Optional[str] = ...) -> None: ...

class ListRegressionArtifactsRequest(_message.Message):
    __slots__ = ("kind", "scenario_id", "upload_status")
    KIND_FIELD_NUMBER: _ClassVar[int]
    SCENARIO_ID_FIELD_NUMBER: _ClassVar[int]
    UPLOAD_STATUS_FIELD_NUMBER: _ClassVar[int]
    kind: str
    scenario_id: str
    upload_status: str
    def __init__(self, kind: _Optional[str] = ..., scenario_id: _Optional[str] = ..., upload_status: _Optional[str] = ...) -> None: ...

class ListRegressionArtifactsResponse(_message.Message):
    __slots__ = ("artifacts", "artifact_tree")
    ARTIFACTS_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_TREE_FIELD_NUMBER: _ClassVar[int]
    artifacts: _containers.RepeatedCompositeFieldContainer[RegressionArtifact]
    artifact_tree: _containers.RepeatedCompositeFieldContainer[RegressionArtifactTreeNode]
    def __init__(self, artifacts: _Optional[_Iterable[_Union[RegressionArtifact, _Mapping]]] = ..., artifact_tree: _Optional[_Iterable[_Union[RegressionArtifactTreeNode, _Mapping]]] = ...) -> None: ...
