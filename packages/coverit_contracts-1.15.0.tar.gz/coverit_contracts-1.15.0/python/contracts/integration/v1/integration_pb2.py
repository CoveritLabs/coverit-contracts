from coverit.integration.v1.integration_pb2 import *
