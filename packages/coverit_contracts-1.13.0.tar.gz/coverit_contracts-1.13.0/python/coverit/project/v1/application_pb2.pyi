from validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateTargetApplicationRequest(_message.Message):
    __slots__ = ("name", "base_url")
    NAME_FIELD_NUMBER: _ClassVar[int]
    BASE_URL_FIELD_NUMBER: _ClassVar[int]
    name: str
    base_url: str
    def __init__(self, name: _Optional[str] = ..., base_url: _Optional[str] = ...) -> None: ...

class UpdateTargetApplicationRequest(_message.Message):
    __slots__ = ("name", "base_url")
    NAME_FIELD_NUMBER: _ClassVar[int]
    BASE_URL_FIELD_NUMBER: _ClassVar[int]
    name: str
    base_url: str
    def __init__(self, name: _Optional[str] = ..., base_url: _Optional[str] = ...) -> None: ...

class CreateTargetApplicationVersionRequest(_message.Message):
    __slots__ = ("version",)
    VERSION_FIELD_NUMBER: _ClassVar[int]
    version: str
    def __init__(self, version: _Optional[str] = ...) -> None: ...

class CreateRegressionCodebaseRequest(_message.Message):
    __slots__ = ("framework_name", "repository_url", "api_key")
    FRAMEWORK_NAME_FIELD_NUMBER: _ClassVar[int]
    REPOSITORY_URL_FIELD_NUMBER: _ClassVar[int]
    API_KEY_FIELD_NUMBER: _ClassVar[int]
    framework_name: str
    repository_url: str
    api_key: str
    def __init__(self, framework_name: _Optional[str] = ..., repository_url: _Optional[str] = ..., api_key: _Optional[str] = ...) -> None: ...

class UpdateRegressionCodebaseRequest(_message.Message):
    __slots__ = ("framework_name", "repository_url", "api_key")
    FRAMEWORK_NAME_FIELD_NUMBER: _ClassVar[int]
    REPOSITORY_URL_FIELD_NUMBER: _ClassVar[int]
    API_KEY_FIELD_NUMBER: _ClassVar[int]
    framework_name: str
    repository_url: str
    api_key: str
    def __init__(self, framework_name: _Optional[str] = ..., repository_url: _Optional[str] = ..., api_key: _Optional[str] = ...) -> None: ...

class CreateTargetApplicationResponse(_message.Message):
    __slots__ = ("id", "api_key", "api_key_preview")
    ID_FIELD_NUMBER: _ClassVar[int]
    API_KEY_FIELD_NUMBER: _ClassVar[int]
    API_KEY_PREVIEW_FIELD_NUMBER: _ClassVar[int]
    id: str
    api_key: str
    api_key_preview: str
    def __init__(self, id: _Optional[str] = ..., api_key: _Optional[str] = ..., api_key_preview: _Optional[str] = ...) -> None: ...

class TargetApplicationResponse(_message.Message):
    __slots__ = ("id", "name", "base_url", "versions", "api_key_preview", "api_key_created_at", "api_key_rotated_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    BASE_URL_FIELD_NUMBER: _ClassVar[int]
    VERSIONS_FIELD_NUMBER: _ClassVar[int]
    API_KEY_PREVIEW_FIELD_NUMBER: _ClassVar[int]
    API_KEY_CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    API_KEY_ROTATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    base_url: str
    versions: _containers.RepeatedCompositeFieldContainer[TargetApplicationVersionResponse]
    api_key_preview: str
    api_key_created_at: str
    api_key_rotated_at: str
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ..., base_url: _Optional[str] = ..., versions: _Optional[_Iterable[_Union[TargetApplicationVersionResponse, _Mapping]]] = ..., api_key_preview: _Optional[str] = ..., api_key_created_at: _Optional[str] = ..., api_key_rotated_at: _Optional[str] = ...) -> None: ...

class TargetApplicationVersionResponse(_message.Message):
    __slots__ = ("id", "version")
    ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    id: str
    version: str
    def __init__(self, id: _Optional[str] = ..., version: _Optional[str] = ...) -> None: ...

class RegressionCodebaseResponse(_message.Message):
    __slots__ = ("id", "framework_name", "repository_url")
    ID_FIELD_NUMBER: _ClassVar[int]
    FRAMEWORK_NAME_FIELD_NUMBER: _ClassVar[int]
    REPOSITORY_URL_FIELD_NUMBER: _ClassVar[int]
    id: str
    framework_name: str
    repository_url: str
    def __init__(self, id: _Optional[str] = ..., framework_name: _Optional[str] = ..., repository_url: _Optional[str] = ...) -> None: ...

class RotateTargetApplicationApiKeyResponse(_message.Message):
    __slots__ = ("api_key", "api_key_preview")
    API_KEY_FIELD_NUMBER: _ClassVar[int]
    API_KEY_PREVIEW_FIELD_NUMBER: _ClassVar[int]
    api_key: str
    api_key_preview: str
    def __init__(self, api_key: _Optional[str] = ..., api_key_preview: _Optional[str] = ...) -> None: ...
