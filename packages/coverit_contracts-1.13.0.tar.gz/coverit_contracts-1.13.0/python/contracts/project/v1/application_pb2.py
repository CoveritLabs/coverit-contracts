from coverit.project.v1.application_pb2 import *
