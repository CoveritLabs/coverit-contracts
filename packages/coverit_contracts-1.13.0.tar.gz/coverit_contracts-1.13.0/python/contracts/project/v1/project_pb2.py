from coverit.project.v1.project_pb2 import *
