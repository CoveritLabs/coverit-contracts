"""protobuf alias package."""
