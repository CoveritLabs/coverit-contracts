from coverit.regression.v1.regression_pb2 import *
