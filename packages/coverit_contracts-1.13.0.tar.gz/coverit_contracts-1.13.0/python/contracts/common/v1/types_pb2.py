from coverit.common.v1.types_pb2 import *
