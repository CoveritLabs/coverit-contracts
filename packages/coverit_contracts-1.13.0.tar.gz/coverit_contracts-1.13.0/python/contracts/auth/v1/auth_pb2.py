from coverit.auth.v1.auth_pb2 import *
