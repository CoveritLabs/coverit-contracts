from coverit.crawler.v1.crawler_pb2 import *
