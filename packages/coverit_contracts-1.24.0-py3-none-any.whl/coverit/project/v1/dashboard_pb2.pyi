from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ProjectDashboardTotals(_message.Message):
    __slots__ = ("total_states", "total_transitions", "total_on_demand_sessions", "total_runs", "passed_count", "warning_count", "failed_count", "reported_warning_count", "reported_failed_count")
    TOTAL_STATES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TRANSITIONS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ON_DEMAND_SESSIONS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_RUNS_FIELD_NUMBER: _ClassVar[int]
    PASSED_COUNT_FIELD_NUMBER: _ClassVar[int]
    WARNING_COUNT_FIELD_NUMBER: _ClassVar[int]
    FAILED_COUNT_FIELD_NUMBER: _ClassVar[int]
    REPORTED_WARNING_COUNT_FIELD_NUMBER: _ClassVar[int]
    REPORTED_FAILED_COUNT_FIELD_NUMBER: _ClassVar[int]
    total_states: int
    total_transitions: int
    total_on_demand_sessions: int
    total_runs: int
    passed_count: int
    warning_count: int
    failed_count: int
    reported_warning_count: int
    reported_failed_count: int
    def __init__(self, total_states: _Optional[int] = ..., total_transitions: _Optional[int] = ..., total_on_demand_sessions: _Optional[int] = ..., total_runs: _Optional[int] = ..., passed_count: _Optional[int] = ..., warning_count: _Optional[int] = ..., failed_count: _Optional[int] = ..., reported_warning_count: _Optional[int] = ..., reported_failed_count: _Optional[int] = ...) -> None: ...

class ProjectCoveragePoint(_message.Message):
    __slots__ = ("application_id", "application_name", "version_id", "version", "percentage", "covered_transitions", "total_transitions", "total_states", "session_count", "calculated_at")
    APPLICATION_ID_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PERCENTAGE_FIELD_NUMBER: _ClassVar[int]
    COVERED_TRANSITIONS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TRANSITIONS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_STATES_FIELD_NUMBER: _ClassVar[int]
    SESSION_COUNT_FIELD_NUMBER: _ClassVar[int]
    CALCULATED_AT_FIELD_NUMBER: _ClassVar[int]
    application_id: str
    application_name: str
    version_id: str
    version: str
    percentage: float
    covered_transitions: int
    total_transitions: int
    total_states: int
    session_count: int
    calculated_at: str
    def __init__(self, application_id: _Optional[str] = ..., application_name: _Optional[str] = ..., version_id: _Optional[str] = ..., version: _Optional[str] = ..., percentage: _Optional[float] = ..., covered_transitions: _Optional[int] = ..., total_transitions: _Optional[int] = ..., total_states: _Optional[int] = ..., session_count: _Optional[int] = ..., calculated_at: _Optional[str] = ...) -> None: ...

class ProjectRunTrendPoint(_message.Message):
    __slots__ = ("id", "run_id", "display_name", "status", "application_id", "application_name", "version_id", "version", "passed_count", "warning_count", "failed_count", "duration_ms", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_ID_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PASSED_COUNT_FIELD_NUMBER: _ClassVar[int]
    WARNING_COUNT_FIELD_NUMBER: _ClassVar[int]
    FAILED_COUNT_FIELD_NUMBER: _ClassVar[int]
    DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    run_id: str
    display_name: str
    status: str
    application_id: str
    application_name: str
    version_id: str
    version: str
    passed_count: int
    warning_count: int
    failed_count: int
    duration_ms: int
    created_at: str
    def __init__(self, id: _Optional[str] = ..., run_id: _Optional[str] = ..., display_name: _Optional[str] = ..., status: _Optional[str] = ..., application_id: _Optional[str] = ..., application_name: _Optional[str] = ..., version_id: _Optional[str] = ..., version: _Optional[str] = ..., passed_count: _Optional[int] = ..., warning_count: _Optional[int] = ..., failed_count: _Optional[int] = ..., duration_ms: _Optional[int] = ..., created_at: _Optional[str] = ...) -> None: ...

class ProjectCrawlSessionTrendPoint(_message.Message):
    __slots__ = ("id", "application_id", "application_name", "version_id", "version", "state_count", "transition_count", "created_at", "finished_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_ID_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    STATE_COUNT_FIELD_NUMBER: _ClassVar[int]
    TRANSITION_COUNT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    FINISHED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    application_id: str
    application_name: str
    version_id: str
    version: str
    state_count: int
    transition_count: int
    created_at: str
    finished_at: str
    def __init__(self, id: _Optional[str] = ..., application_id: _Optional[str] = ..., application_name: _Optional[str] = ..., version_id: _Optional[str] = ..., version: _Optional[str] = ..., state_count: _Optional[int] = ..., transition_count: _Optional[int] = ..., created_at: _Optional[str] = ..., finished_at: _Optional[str] = ...) -> None: ...

class ProjectTestFlowBreakdownPoint(_message.Message):
    __slots__ = ("type", "count", "total_steps", "generated_count", "stale_count", "pending_count")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    TOTAL_STEPS_FIELD_NUMBER: _ClassVar[int]
    GENERATED_COUNT_FIELD_NUMBER: _ClassVar[int]
    STALE_COUNT_FIELD_NUMBER: _ClassVar[int]
    PENDING_COUNT_FIELD_NUMBER: _ClassVar[int]
    type: str
    count: int
    total_steps: int
    generated_count: int
    stale_count: int
    pending_count: int
    def __init__(self, type: _Optional[str] = ..., count: _Optional[int] = ..., total_steps: _Optional[int] = ..., generated_count: _Optional[int] = ..., stale_count: _Optional[int] = ..., pending_count: _Optional[int] = ...) -> None: ...

class ProjectActivity(_message.Message):
    __slots__ = ("id", "project_id", "event_type", "entity_type", "entity_id", "message", "actor_user_id", "actor_name", "actor_email", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ACTOR_USER_ID_FIELD_NUMBER: _ClassVar[int]
    ACTOR_NAME_FIELD_NUMBER: _ClassVar[int]
    ACTOR_EMAIL_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    project_id: str
    event_type: str
    entity_type: str
    entity_id: str
    message: str
    actor_user_id: str
    actor_name: str
    actor_email: str
    created_at: str
    def __init__(self, id: _Optional[str] = ..., project_id: _Optional[str] = ..., event_type: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., message: _Optional[str] = ..., actor_user_id: _Optional[str] = ..., actor_name: _Optional[str] = ..., actor_email: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class ProjectDashboardResponse(_message.Message):
    __slots__ = ("totals", "coverage_by_application", "coverage_by_version", "run_trend", "crawl_session_trend", "test_flow_breakdown", "recent_activities")
    TOTALS_FIELD_NUMBER: _ClassVar[int]
    COVERAGE_BY_APPLICATION_FIELD_NUMBER: _ClassVar[int]
    COVERAGE_BY_VERSION_FIELD_NUMBER: _ClassVar[int]
    RUN_TREND_FIELD_NUMBER: _ClassVar[int]
    CRAWL_SESSION_TREND_FIELD_NUMBER: _ClassVar[int]
    TEST_FLOW_BREAKDOWN_FIELD_NUMBER: _ClassVar[int]
    RECENT_ACTIVITIES_FIELD_NUMBER: _ClassVar[int]
    totals: ProjectDashboardTotals
    coverage_by_application: _containers.RepeatedCompositeFieldContainer[ProjectCoveragePoint]
    coverage_by_version: _containers.RepeatedCompositeFieldContainer[ProjectCoveragePoint]
    run_trend: _containers.RepeatedCompositeFieldContainer[ProjectRunTrendPoint]
    crawl_session_trend: _containers.RepeatedCompositeFieldContainer[ProjectCrawlSessionTrendPoint]
    test_flow_breakdown: _containers.RepeatedCompositeFieldContainer[ProjectTestFlowBreakdownPoint]
    recent_activities: _containers.RepeatedCompositeFieldContainer[ProjectActivity]
    def __init__(self, totals: _Optional[_Union[ProjectDashboardTotals, _Mapping]] = ..., coverage_by_application: _Optional[_Iterable[_Union[ProjectCoveragePoint, _Mapping]]] = ..., coverage_by_version: _Optional[_Iterable[_Union[ProjectCoveragePoint, _Mapping]]] = ..., run_trend: _Optional[_Iterable[_Union[ProjectRunTrendPoint, _Mapping]]] = ..., crawl_session_trend: _Optional[_Iterable[_Union[ProjectCrawlSessionTrendPoint, _Mapping]]] = ..., test_flow_breakdown: _Optional[_Iterable[_Union[ProjectTestFlowBreakdownPoint, _Mapping]]] = ..., recent_activities: _Optional[_Iterable[_Union[ProjectActivity, _Mapping]]] = ...) -> None: ...
