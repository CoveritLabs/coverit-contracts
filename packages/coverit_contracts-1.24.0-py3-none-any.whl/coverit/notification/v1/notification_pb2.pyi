from validate import validate_pb2 as _validate_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CodegenNotificationStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CODEGEN_NOTIFICATION_STATUS_UNSPECIFIED: _ClassVar[CodegenNotificationStatus]
    CODEGEN_NOTIFICATION_STATUS_GENERATED: _ClassVar[CodegenNotificationStatus]
    CODEGEN_NOTIFICATION_STATUS_FAILED: _ClassVar[CodegenNotificationStatus]
CODEGEN_NOTIFICATION_STATUS_UNSPECIFIED: CodegenNotificationStatus
CODEGEN_NOTIFICATION_STATUS_GENERATED: CodegenNotificationStatus
CODEGEN_NOTIFICATION_STATUS_FAILED: CodegenNotificationStatus

class InternalCodegenNotificationRequest(_message.Message):
    __slots__ = ("status", "branch_name", "changed_files", "no_changes", "pushed", "pull_request_url", "error_message", "flow_ids")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    BRANCH_NAME_FIELD_NUMBER: _ClassVar[int]
    CHANGED_FILES_FIELD_NUMBER: _ClassVar[int]
    NO_CHANGES_FIELD_NUMBER: _ClassVar[int]
    PUSHED_FIELD_NUMBER: _ClassVar[int]
    PULL_REQUEST_URL_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    FLOW_IDS_FIELD_NUMBER: _ClassVar[int]
    status: CodegenNotificationStatus
    branch_name: str
    changed_files: _containers.RepeatedScalarFieldContainer[str]
    no_changes: bool
    pushed: bool
    pull_request_url: str
    error_message: str
    flow_ids: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, status: _Optional[_Union[CodegenNotificationStatus, str]] = ..., branch_name: _Optional[str] = ..., changed_files: _Optional[_Iterable[str]] = ..., no_changes: _Optional[bool] = ..., pushed: _Optional[bool] = ..., pull_request_url: _Optional[str] = ..., error_message: _Optional[str] = ..., flow_ids: _Optional[_Iterable[str]] = ...) -> None: ...
