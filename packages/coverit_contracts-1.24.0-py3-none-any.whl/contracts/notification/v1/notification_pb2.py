from coverit.notification.v1.notification_pb2 import *
