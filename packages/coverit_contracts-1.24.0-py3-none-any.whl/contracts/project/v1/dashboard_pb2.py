from coverit.project.v1.dashboard_pb2 import *
