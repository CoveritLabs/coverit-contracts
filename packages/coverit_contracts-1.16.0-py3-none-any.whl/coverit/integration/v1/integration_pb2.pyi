from validate import validate_pb2 as _validate_pb2
from coverit.common.v1 import types_pb2 as _types_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class StartIntegrationOAuthResponse(_message.Message):
    __slots__ = ("authorization_url",)
    AUTHORIZATION_URL_FIELD_NUMBER: _ClassVar[int]
    authorization_url: str
    def __init__(self, authorization_url: _Optional[str] = ...) -> None: ...

class IntegrationStatusResponse(_message.Message):
    __slots__ = ("connected", "provider", "scopes", "authorized_by_user", "access_token_expires_at", "refreshed_at", "created_at", "updated_at", "jira", "jira_reporting_config")
    CONNECTED_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    SCOPES_FIELD_NUMBER: _ClassVar[int]
    AUTHORIZED_BY_USER_FIELD_NUMBER: _ClassVar[int]
    ACCESS_TOKEN_EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    REFRESHED_AT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    JIRA_FIELD_NUMBER: _ClassVar[int]
    JIRA_REPORTING_CONFIG_FIELD_NUMBER: _ClassVar[int]
    connected: bool
    provider: str
    scopes: _containers.RepeatedScalarFieldContainer[str]
    authorized_by_user: _types_pb2.UserInfo
    access_token_expires_at: str
    refreshed_at: str
    created_at: str
    updated_at: str
    jira: JiraIntegrationDetails
    jira_reporting_config: JiraReportingConfig
    def __init__(self, connected: _Optional[bool] = ..., provider: _Optional[str] = ..., scopes: _Optional[_Iterable[str]] = ..., authorized_by_user: _Optional[_Union[_types_pb2.UserInfo, _Mapping]] = ..., access_token_expires_at: _Optional[str] = ..., refreshed_at: _Optional[str] = ..., created_at: _Optional[str] = ..., updated_at: _Optional[str] = ..., jira: _Optional[_Union[JiraIntegrationDetails, _Mapping]] = ..., jira_reporting_config: _Optional[_Union[JiraReportingConfig, _Mapping]] = ...) -> None: ...

class JiraIntegrationDetails(_message.Message):
    __slots__ = ("cloud_id", "site_name", "site_url")
    CLOUD_ID_FIELD_NUMBER: _ClassVar[int]
    SITE_NAME_FIELD_NUMBER: _ClassVar[int]
    SITE_URL_FIELD_NUMBER: _ClassVar[int]
    cloud_id: str
    site_name: str
    site_url: str
    def __init__(self, cloud_id: _Optional[str] = ..., site_name: _Optional[str] = ..., site_url: _Optional[str] = ...) -> None: ...

class JiraIssueProject(_message.Message):
    __slots__ = ("id", "key", "name")
    ID_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    id: str
    key: str
    name: str
    def __init__(self, id: _Optional[str] = ..., key: _Optional[str] = ..., name: _Optional[str] = ...) -> None: ...

class JiraIssueType(_message.Message):
    __slots__ = ("id", "name")
    ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    id: str
    name: str
    def __init__(self, id: _Optional[str] = ..., name: _Optional[str] = ...) -> None: ...

class JiraReportingConfig(_message.Message):
    __slots__ = ("enabled", "project", "issue_type")
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    ISSUE_TYPE_FIELD_NUMBER: _ClassVar[int]
    enabled: bool
    project: JiraIssueProject
    issue_type: JiraIssueType
    def __init__(self, enabled: _Optional[bool] = ..., project: _Optional[_Union[JiraIssueProject, _Mapping]] = ..., issue_type: _Optional[_Union[JiraIssueType, _Mapping]] = ...) -> None: ...

class JiraReportingOptions(_message.Message):
    __slots__ = ("projects", "issue_types")
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    ISSUE_TYPES_FIELD_NUMBER: _ClassVar[int]
    projects: _containers.RepeatedCompositeFieldContainer[JiraIssueProject]
    issue_types: _containers.RepeatedCompositeFieldContainer[JiraIssueType]
    def __init__(self, projects: _Optional[_Iterable[_Union[JiraIssueProject, _Mapping]]] = ..., issue_types: _Optional[_Iterable[_Union[JiraIssueType, _Mapping]]] = ...) -> None: ...

class UpdateIntegrationReportingConfigRequest(_message.Message):
    __slots__ = ("jira",)
    JIRA_FIELD_NUMBER: _ClassVar[int]
    jira: JiraReportingConfig
    def __init__(self, jira: _Optional[_Union[JiraReportingConfig, _Mapping]] = ...) -> None: ...

class IntegrationReportingConfigResponse(_message.Message):
    __slots__ = ("provider", "jira")
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    JIRA_FIELD_NUMBER: _ClassVar[int]
    provider: str
    jira: JiraReportingConfig
    def __init__(self, provider: _Optional[str] = ..., jira: _Optional[_Union[JiraReportingConfig, _Mapping]] = ...) -> None: ...

class IntegrationReportingOptionsResponse(_message.Message):
    __slots__ = ("provider", "jira")
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    JIRA_FIELD_NUMBER: _ClassVar[int]
    provider: str
    jira: JiraReportingOptions
    def __init__(self, provider: _Optional[str] = ..., jira: _Optional[_Union[JiraReportingOptions, _Mapping]] = ...) -> None: ...
