from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ProjectDashboardVersionRef(_message.Message):
    __slots__ = ("id", "version", "application_id", "application_name")
    ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_ID_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_NAME_FIELD_NUMBER: _ClassVar[int]
    id: str
    version: str
    application_id: str
    application_name: str
    def __init__(self, id: _Optional[str] = ..., version: _Optional[str] = ..., application_id: _Optional[str] = ..., application_name: _Optional[str] = ...) -> None: ...

class ProjectCoverageSummary(_message.Message):
    __slots__ = ("percentage", "covered_transitions", "total_transitions", "crawl_session_id", "calculated_at")
    PERCENTAGE_FIELD_NUMBER: _ClassVar[int]
    COVERED_TRANSITIONS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_TRANSITIONS_FIELD_NUMBER: _ClassVar[int]
    CRAWL_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    CALCULATED_AT_FIELD_NUMBER: _ClassVar[int]
    percentage: float
    covered_transitions: int
    total_transitions: int
    crawl_session_id: str
    calculated_at: str
    def __init__(self, percentage: _Optional[float] = ..., covered_transitions: _Optional[int] = ..., total_transitions: _Optional[int] = ..., crawl_session_id: _Optional[str] = ..., calculated_at: _Optional[str] = ...) -> None: ...

class ProjectRunStatistics(_message.Message):
    __slots__ = ("passed_count", "warning_count", "failed_count", "reported_warning_count", "reported_failed_count", "total_runs")
    PASSED_COUNT_FIELD_NUMBER: _ClassVar[int]
    WARNING_COUNT_FIELD_NUMBER: _ClassVar[int]
    FAILED_COUNT_FIELD_NUMBER: _ClassVar[int]
    REPORTED_WARNING_COUNT_FIELD_NUMBER: _ClassVar[int]
    REPORTED_FAILED_COUNT_FIELD_NUMBER: _ClassVar[int]
    TOTAL_RUNS_FIELD_NUMBER: _ClassVar[int]
    passed_count: int
    warning_count: int
    failed_count: int
    reported_warning_count: int
    reported_failed_count: int
    total_runs: int
    def __init__(self, passed_count: _Optional[int] = ..., warning_count: _Optional[int] = ..., failed_count: _Optional[int] = ..., reported_warning_count: _Optional[int] = ..., reported_failed_count: _Optional[int] = ..., total_runs: _Optional[int] = ...) -> None: ...

class ProjectLatestRun(_message.Message):
    __slots__ = ("id", "run_id", "display_name", "status", "application_id", "application_name", "version_id", "version", "passed_count", "warning_count", "failed_count", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    RUN_ID_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_ID_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    PASSED_COUNT_FIELD_NUMBER: _ClassVar[int]
    WARNING_COUNT_FIELD_NUMBER: _ClassVar[int]
    FAILED_COUNT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    run_id: str
    display_name: str
    status: str
    application_id: str
    application_name: str
    version_id: str
    version: str
    passed_count: int
    warning_count: int
    failed_count: int
    created_at: str
    def __init__(self, id: _Optional[str] = ..., run_id: _Optional[str] = ..., display_name: _Optional[str] = ..., status: _Optional[str] = ..., application_id: _Optional[str] = ..., application_name: _Optional[str] = ..., version_id: _Optional[str] = ..., version: _Optional[str] = ..., passed_count: _Optional[int] = ..., warning_count: _Optional[int] = ..., failed_count: _Optional[int] = ..., created_at: _Optional[str] = ...) -> None: ...

class ProjectLatestCrawlSession(_message.Message):
    __slots__ = ("id", "status", "trigger_type", "application_id", "application_name", "version_id", "version", "state_count", "transition_count", "created_at", "started_at", "finished_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_TYPE_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_ID_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    STATE_COUNT_FIELD_NUMBER: _ClassVar[int]
    TRANSITION_COUNT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    FINISHED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    status: str
    trigger_type: str
    application_id: str
    application_name: str
    version_id: str
    version: str
    state_count: int
    transition_count: int
    created_at: str
    started_at: str
    finished_at: str
    def __init__(self, id: _Optional[str] = ..., status: _Optional[str] = ..., trigger_type: _Optional[str] = ..., application_id: _Optional[str] = ..., application_name: _Optional[str] = ..., version_id: _Optional[str] = ..., version: _Optional[str] = ..., state_count: _Optional[int] = ..., transition_count: _Optional[int] = ..., created_at: _Optional[str] = ..., started_at: _Optional[str] = ..., finished_at: _Optional[str] = ...) -> None: ...

class ProjectLatestTestFlow(_message.Message):
    __slots__ = ("id", "crawl_session_id", "application_id", "application_name", "version_id", "version", "checkpoint_state_hash", "checkpoint_url", "is_clipped", "step_count", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    CRAWL_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_ID_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_NAME_FIELD_NUMBER: _ClassVar[int]
    VERSION_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    CHECKPOINT_STATE_HASH_FIELD_NUMBER: _ClassVar[int]
    CHECKPOINT_URL_FIELD_NUMBER: _ClassVar[int]
    IS_CLIPPED_FIELD_NUMBER: _ClassVar[int]
    STEP_COUNT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    crawl_session_id: str
    application_id: str
    application_name: str
    version_id: str
    version: str
    checkpoint_state_hash: str
    checkpoint_url: str
    is_clipped: bool
    step_count: int
    created_at: str
    def __init__(self, id: _Optional[str] = ..., crawl_session_id: _Optional[str] = ..., application_id: _Optional[str] = ..., application_name: _Optional[str] = ..., version_id: _Optional[str] = ..., version: _Optional[str] = ..., checkpoint_state_hash: _Optional[str] = ..., checkpoint_url: _Optional[str] = ..., is_clipped: _Optional[bool] = ..., step_count: _Optional[int] = ..., created_at: _Optional[str] = ...) -> None: ...

class ProjectActivity(_message.Message):
    __slots__ = ("id", "project_id", "event_type", "entity_type", "entity_id", "message", "actor_user_id", "actor_name", "actor_email", "created_at")
    ID_FIELD_NUMBER: _ClassVar[int]
    PROJECT_ID_FIELD_NUMBER: _ClassVar[int]
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_TYPE_FIELD_NUMBER: _ClassVar[int]
    ENTITY_ID_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ACTOR_USER_ID_FIELD_NUMBER: _ClassVar[int]
    ACTOR_NAME_FIELD_NUMBER: _ClassVar[int]
    ACTOR_EMAIL_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    id: str
    project_id: str
    event_type: str
    entity_type: str
    entity_id: str
    message: str
    actor_user_id: str
    actor_name: str
    actor_email: str
    created_at: str
    def __init__(self, id: _Optional[str] = ..., project_id: _Optional[str] = ..., event_type: _Optional[str] = ..., entity_type: _Optional[str] = ..., entity_id: _Optional[str] = ..., message: _Optional[str] = ..., actor_user_id: _Optional[str] = ..., actor_name: _Optional[str] = ..., actor_email: _Optional[str] = ..., created_at: _Optional[str] = ...) -> None: ...

class ProjectDashboardResponse(_message.Message):
    __slots__ = ("selected_version", "coverage", "run_statistics", "latest_runs", "latest_crawl_sessions", "latest_test_flows", "recent_activities")
    SELECTED_VERSION_FIELD_NUMBER: _ClassVar[int]
    COVERAGE_FIELD_NUMBER: _ClassVar[int]
    RUN_STATISTICS_FIELD_NUMBER: _ClassVar[int]
    LATEST_RUNS_FIELD_NUMBER: _ClassVar[int]
    LATEST_CRAWL_SESSIONS_FIELD_NUMBER: _ClassVar[int]
    LATEST_TEST_FLOWS_FIELD_NUMBER: _ClassVar[int]
    RECENT_ACTIVITIES_FIELD_NUMBER: _ClassVar[int]
    selected_version: ProjectDashboardVersionRef
    coverage: ProjectCoverageSummary
    run_statistics: ProjectRunStatistics
    latest_runs: _containers.RepeatedCompositeFieldContainer[ProjectLatestRun]
    latest_crawl_sessions: _containers.RepeatedCompositeFieldContainer[ProjectLatestCrawlSession]
    latest_test_flows: _containers.RepeatedCompositeFieldContainer[ProjectLatestTestFlow]
    recent_activities: _containers.RepeatedCompositeFieldContainer[ProjectActivity]
    def __init__(self, selected_version: _Optional[_Union[ProjectDashboardVersionRef, _Mapping]] = ..., coverage: _Optional[_Union[ProjectCoverageSummary, _Mapping]] = ..., run_statistics: _Optional[_Union[ProjectRunStatistics, _Mapping]] = ..., latest_runs: _Optional[_Iterable[_Union[ProjectLatestRun, _Mapping]]] = ..., latest_crawl_sessions: _Optional[_Iterable[_Union[ProjectLatestCrawlSession, _Mapping]]] = ..., latest_test_flows: _Optional[_Iterable[_Union[ProjectLatestTestFlow, _Mapping]]] = ..., recent_activities: _Optional[_Iterable[_Union[ProjectActivity, _Mapping]]] = ...) -> None: ...
